
WARNING: not working version !!!

radar is a concept library not elaborated yet that implements a Ping))) based Radar
with the use of a pan/tilt servo's. Was written after a question on the forum but 
never finished it. Still, it has some interesting concepts wrt determine the position of 
pan/tilt while in progress. 

In short a lot todo



