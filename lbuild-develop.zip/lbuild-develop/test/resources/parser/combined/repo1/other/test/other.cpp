
#include <iostream>

void
test()
{
	std::cout << "Test Function" << std::endl;
}
