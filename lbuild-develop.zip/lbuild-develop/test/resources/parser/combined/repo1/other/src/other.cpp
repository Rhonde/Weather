
#include <iostream>

void
test();

int
main(void)
{
	std::cout << "Hello World!" << std::endl;

	test();

	return 0;
}
