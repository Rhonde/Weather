
Codestyle
---------

We try to follow the [PEP-8][] codestyle for the code.

For the docstrings the [Google style][] is used.

[PEP-8]: <https://www.python.org/dev/peps/pep-0008/>
[Google style]: <https://google.github.io/styleguide/pyguide.html?showone=Comments#Comments>
