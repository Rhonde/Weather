
class ParserException(Exception):
    pass

class DeviceIdentifierException(Exception):
    pass
