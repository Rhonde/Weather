# ARM CMSIS-DSP

This module provides the CMSIS-DSP library.
Please [see the API documentation][docs] for details.

[docs]: http://arm-software.github.io/CMSIS_5/DSP/html/modules.html
